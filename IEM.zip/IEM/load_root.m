% load_root.m

% Replace "root" with the full directory in which IEM_*.m files sit (should be
% in /berlin_workshop/)


function root = load_root

%root = '/Users/Tommy/Dropbox/documents/ucsd/serences/Talks/BerlinWorkshop/tutorial/';%[pwd '/'];%'/usr/local/serenceslab/tommy/berlin_workshop/';
root =  fileparts(which(mfilename));

root = fullfile(root, filesep);

return